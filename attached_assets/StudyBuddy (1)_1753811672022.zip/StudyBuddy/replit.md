# Laundry Booking System

## Overview

This is a Flask-based web application for managing laundry bookings in what appears to be a dormitory or residential setting. The system allows students to register, login, book laundry time slots, and view their booking history. It also includes an admin interface for managing all bookings.

## User Preferences

Preferred communication style: Simple, everyday language without emojis.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension
- **Session Management**: Flask's built-in session handling
- **Database**: Flexible database support with fallback to SQLite for development

### Frontend Architecture
- **Template Engine**: Jinja2 (Flask's default)
- **CSS Framework**: Bootstrap with dark theme
- **Icons**: Font Awesome
- **Layout**: Responsive design using Bootstrap grid system

### Application Structure
The application follows a modular Flask structure:
- `app.py`: Application factory and configuration
- `main.py`: Application entry point
- `models.py`: Database models
- `routes.py`: Route handlers (incomplete in provided files)
- `templates/`: HTML templates with Jinja2

## Key Components

### Database Models
1. **Booking Model**: Stores laundry booking information
   - Student details (name, room number)
   - Scheduling (date, time slot)
   - Service details (cloth type, wash type)
   - Payment information (method, status)
   - Booking status tracking

2. **User Model**: Handles user authentication
   - Username/password authentication
   - Simple credential storage (note: passwords are stored in plain text)

### Route Structure
- `/` - Dashboard (home page)
- `/student_login` - Student authentication
- `/register` - Student registration
- `/book` - Laundry slot booking
- `/history` - Booking history view
- `/admin_login` - Admin authentication
- `/admin_dashboard` - Admin management interface
- `/help` - Comprehensive help and instructions page

### Template System
- **Base Template**: Provides consistent navigation and styling
- **User Templates**: Login, registration, booking, history
- **Admin Templates**: Admin login and dashboard
- **Responsive Design**: Mobile-friendly interface

## Data Flow

1. **User Registration/Login**: Users register with username/password, stored in User table
2. **Booking Process**: Authenticated users can create bookings with scheduling and service preferences
3. **Booking Management**: Bookings are stored with status tracking (Pending, Confirmed, Completed, Cancelled)
4. **Payment Tracking**: Payment method and status are recorded per booking
5. **Admin Oversight**: Admins can view and manage all bookings through dedicated interface

## External Dependencies

### Python Packages
- Flask: Web framework
- Flask-SQLAlchemy: Database ORM
- Werkzeug: WSGI utilities (ProxyFix for deployment)

### Frontend Dependencies
- Bootstrap CSS (via CDN): UI framework with dark theme
- Font Awesome (via CDN): Icon library

### Database
- **Development**: SQLite (automatic fallback)
- **Production**: Configurable via DATABASE_URL environment variable
- **Connection Pooling**: Configured for production use with pool recycling

## Deployment Strategy

### Environment Configuration
- **Secret Key**: Configurable via SESSION_SECRET environment variable
- **Database**: Flexible configuration supporting various database backends
- **Development Mode**: Built-in Flask development server
- **Production Ready**: ProxyFix middleware for reverse proxy deployment

### Database Management
- Automatic table creation on application startup
- Instance folder for SQLite database in development
- Connection pooling and health checks for production databases

### Security Considerations
- Session-based authentication
- CSRF protection through form handling
- Environment-based configuration for secrets

**Note**: The current authentication system stores passwords in plain text, which should be upgraded to use password hashing for production use.

### Scalability Features
- Database connection pooling
- Modular code structure for easy extension
- Template inheritance for consistent UI updates
- Session-based state management